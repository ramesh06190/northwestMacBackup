//
//  ViewController.swift
//  CourseDsiplayApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 3/20/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var cnum: UILabel!
    @IBOutlet weak var ctitle: UILabel!
    @IBOutlet weak var semofr: UILabel!
    @IBOutlet weak var displayImg: UIImageView!
    let courses = [["img01","44555","Network Security","Fall 2022"],["img02","44643","ios","Spring 2023"],["img03","44656","Streaming Data","Fall 2024"]]
    
    var imgNum = 0
    
    @IBOutlet weak var nxtBtn: UIButton!
    
    @IBOutlet weak var prevBtn: UIButton!
    
    
    @IBAction func nxtBtnClick(_ sender: UIButton) {
        imgNum += 1
        UpdateCourse(imgNum)
        prevBtn.isEnabled = true
        if(imgNum == courses.count-1){
            nxtBtn.isEnabled = false
        }
        
    }
    
    @IBAction func prevBtnClick(_ sender: UIButton) {
        imgNum -= 1
        UpdateCourse(imgNum)
        nxtBtn.isEnabled = true
        if(imgNum == 0){
            prevBtn.isEnabled = false
        }
    }
    
    
    func UpdateCourse(_ imgNum:Int){
        displayImg.image = UIImage(named: courses[imgNum][0])
        cnum.text = courses[imgNum][1]
        ctitle.text = courses[imgNum][2]
        semofr.text = courses[imgNum][3]
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        UpdateCourse(imgNum)
        prevBtn.isEnabled = false
        nxtBtn.isEnabled = true
    }
}

