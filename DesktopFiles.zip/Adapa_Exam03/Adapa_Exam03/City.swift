//
//  City.swift
//  Adapa_Exam03
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import Foundation
struct City {
    let cityName: String
    let cityImage: String
}

let city1 = City(cityName: "New York City", cityImage: "new_york")
let city2 = City(cityName: "Los Angeles", cityImage: "los_angeles")
let city3 = City(cityName: "Chicago", cityImage: "chicago")
let city4 = City(cityName: "San Francisco", cityImage: "san_francisco")
let city5 = City(cityName: "Miami", cityImage: "miami")
let city6 = City(cityName: "Seattle", cityImage: "seattle")


let cities: [City] = [city1, city2, city3, city4, city5, city6]
