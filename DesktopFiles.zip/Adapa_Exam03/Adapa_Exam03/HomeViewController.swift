//
//  ViewController.swift
//  Adapa_Exam03
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }
    
    func tableView(_ tableView:
                   UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = cityTableView.dequeueReusableCell(withIdentifier: "cityCell", for: indexPath)
        cell.textLabel?.text = cities[indexPath.row].cityName
        return cell
    }
    
    
    @IBOutlet weak var cityTableView: UITableView!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        cityTableView.dataSource = self
        cityTableView.delegate = self
        self.title = "Major Cities in USA"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "cityDetailSegue"){
            let destination = segue.destination as! CityDetailViewController
            destination.detailImage = cities[(cityTableView.indexPathForSelectedRow?.row)!].cityImage
            destination.cityTitle = cities[(cityTableView.indexPathForSelectedRow?.row)!].cityName
            
        }
    }
}



