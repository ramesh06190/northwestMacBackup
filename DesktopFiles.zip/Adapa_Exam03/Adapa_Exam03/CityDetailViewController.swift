//
//  CityDetailViewController.swift
//  Adapa_Exam03
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import UIKit

class CityDetailViewController: UIViewController {
    var detailImage : String?
    var cityTitle : String?
    @IBOutlet weak var CityImageView: UIImageView!
    
    @IBOutlet weak var titleOL: UILabel!
    
    @IBAction func animate(_ sender: UIButton) {
        //making the current image opaque.
        UIView.animate(withDuration: 1, animations: {
            self.CityImageView.alpha = 0
        })
        //Assign the new image with animation and make it transparent. (alpha = 1)
        UIView.animate(withDuration: 3, delay:0.4, animations: {
            self.CityImageView.alpha = 1
            self.CityImageView.image = UIImage(named: self.detailImage!)
        })
    }
          override func viewDidLoad() {
              super.viewDidLoad()
              CityImageView.image = UIImage(named: detailImage!)
              titleOL.text = cityTitle
              // Do any additional setup after loading the view.
          }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
