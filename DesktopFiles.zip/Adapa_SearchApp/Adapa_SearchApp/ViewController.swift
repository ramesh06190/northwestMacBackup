//
//  ViewController.swift
//  Adapa_SearchApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 3/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    var actors_keywords = ["actor",
                           "movie",
                           "hero",
                           "film","director"]
    var cricket_keywords = ["cricketer","batsman","bowler","captain","all-rounder"]
    var food_keywords = ["food","meal","dinner","lunch","breakfast"]
    
    var images = [["actors01","actors02","actors03","actors04","actors05"],["cric01","cric02","cric03","cric04","cric05"],["food01","food02","food03","food04","food05"]]
    var topicNum = 0;
    var imgNum = 0;
    
    @IBOutlet weak var nxtBtn: UIButton!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var prevBtn: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        prevBtn.isEnabled = true
        imgNum+=1
        loadContent(topicNum,imgNum)
        if(imgNum == images[0].count-1){
            nxtBtn.isEnabled = false
        }
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        nxtBtn.isEnabled = true
        imgNum-=1
        loadContent(topicNum,imgNum)
        if(imgNum == 0){
            prevBtn.isEnabled = false
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchBtn.isEnabled = false
        topicNum = 0
        imgNum = 0
        searchTextField.text = ""
        nxtBtn.isHidden = true
        prevBtn.isHidden = true
        resetBtn.isHidden = true
        resultImage.image = UIImage(named: "Image 1")
        topicInfoText.text = ""
    }
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        nxtBtn.isHidden = false
        prevBtn.isHidden = false
        resetBtn.isHidden = false
        if(imgNum == 0){
            prevBtn.isEnabled = false
        }
        if(actors_keywords.contains(searchTextField.text!.lowercased())){
            topicNum = 0
            loadContent(topicNum,imgNum)
        }
        else if(cricket_keywords.contains(searchTextField.text!.lowercased())){
            topicNum = 1
            loadContent(topicNum,imgNum)
        }
        else if(food_keywords.contains(searchTextField.text!.lowercased())){
            topicNum = 2
            loadContent(topicNum,imgNum)
        }
        else{
            resultImage.image = UIImage(named: "Image")
            nxtBtn.isHidden = true
            prevBtn.isHidden = true
            resetBtn.isHidden = true
            topicInfoText.text = ""
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBtn.isEnabled = false
        // Do any additional setup after loading the view.
        topicNum = 0
        imgNum = 0
        searchTextField.text = ""
        nxtBtn.isHidden = true
        prevBtn.isHidden = true
        resetBtn.isHidden = true
        resultImage.image = UIImage(named: "Image 1")
        topicInfoText.text = ""
        
    }
    
    func loadContent(_ topicnum:Int,_ imgnum:Int){
        resultImage.image = UIImage(named: images[topicnum][imgnum])
        topicInfoText.text = topics[topicnum][imgnum]
    }
    
    @IBAction func searchTxtField(_ sender: Any) {
        
        searchBtn.isEnabled = true
        if(searchTextField.text == ""){
            searchBtn.isEnabled = false
        }

    }
    
    
    var topics = [["RRR[a] is a 2022 Indian Telugu-language epic action drama film directed by S. S. Rajamouli, who co-wrote the film with V. Vijayendra Prasad. It was produced by D. V. V. Danayya of DVV Entertainment.","Khaleja[a] (transl. Courage)[2] is a 2010 Indian Telugu-language action comedy film written and directed by Trivikram Srinivas. The film stars Mahesh Babu, Anushka Shetty and Prakash Raj, while Shafi , Sunil, Brahmanandam and Ali play supporting roles.","ersey is a 2019 Indian Telugu-language sports drama film written and directed by Gowtam Tinnanuri and produced by Suryadevara Naga Vamsi under Sithara Entertainments. It stars Nani and Shraddha Srinath with Ronit Kamra, Sathyaraj, Harish Kalyan, Sanusha, Sampath Raj and Viswant Duddumpudi in pivotal roles.","K.G.F: Chapter 1 is a 2018 Indian Kannada-language period action film[5] written and directed by Prashanth Neel, and produced by Vijay Kiragandur under the banner of Hombale Films. It is the first of two installments in the series, followed by K.G.F: Chapter 2.","Pokiri (transl. Rogue) is a 2006 Indian Telugu-language action thriller and gangster film written and directed by Puri Jagannadh. The film was produced by Jagannadh and Manjula Ghattamaneni by their respective production companies Vaishno Academy and Indira Productions. The film stars Mahesh Babu"],["MS Dhoni, is a former Indian cricketer and captain of the Indian national team in limited-overs formats from 2007 to 2017, and in Test cricket from 2008 to 2014. He is also the current captain of Chennai Super Kings in the Indian Premier League. Under his captaincy, India won the 2007 ICC World Twenty20, the 2011 Cricket World Cup, and the 2013 ICC Champions Trophy, the most by any captain.","Sachin Ramesh Tendulkar born 24 April 1973 is an Indian former international cricketer who captained the Indian national team. Nicknamed The Little Master[4] and Master Blaster[5], he is regarded as one of the greatest batsmen in the history of cricket.[6] He is the all-time highest run-scorer in both ODI and Test cricket with more than 18,000 runs and 15,000 total runs respectively.","Virat Kohli is an Indian international cricketer and the former captain of the India national team who plays as a right-handed batsman for Royal Challengers Bangalore in the IPL and for the Delhi in Indian domestic cricket. Widely regarded as one of the greatest batsmen of all time","Kapil Dev Ramlal Nikhanj (born 6 January 1959) is an Indian former cricketer. He was a fast-medium bowler and a hard-hitting middle-order batsman, and was named by Wisden as the Indian Cricketer of the Century in 2002.","Sourav Chandidas Ganguly ( born 8 July 1972), affectionately known as Dada (meaning elder brother in Bengali), is an Indian cricket administrator, commentator and former national cricket team captain"],["A dosa, also called dosai, dosey, dwashi or dosha is a thin pancake in South Indian cuisine made from a fermented batter of ground black lentils and rice. Dosas are popular in South Asia as well as around the world. Dosas are served hot, often with chutney and sambar.","Biryani is one of the most popular dishes in South Asia, as well as among the diaspora from the region. Similar dishes are also prepared in other parts of the world such as in Iraq, Myanmar, Thailand, and Malaysia.","Pulihora, also known as puliyogare, puliyodarai, pulinchoru, kokum rice, or simply lemon or tamarind rice or Pavan Maruthi, is a very common and traditional rice preparation in the South Indian states of Telangana, Andhra Pradesh, Karnataka, Kerala and Tamil Nadu.","Chole bhature is often eaten as a breakfast dish, sometimes accompanied with lassi. It can also be street food or a complete meal and may be accompanied with onions, pickled carrots, green chutney or achaar.","Tandoori chicken is a South Asian dish of chicken marinated in yogurt and spices and roasted in a tandoor, a cylindrical clay oven. The dish is now popular world-wide. The modern form of the dish was popularized by the Moti Mahal restaurant in New Delhi in the late 1940s."]]
}

