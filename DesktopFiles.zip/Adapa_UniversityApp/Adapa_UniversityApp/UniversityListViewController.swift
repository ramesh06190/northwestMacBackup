//
//  UniversityListViewController.swift
//  Adapa_UniversityApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/19/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var universityListArray : [UniversityList]?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        universityListArray!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        cell.textLabel?.text = universityListArray![indexPath.row].collegeName
        return cell
    }
    @IBOutlet weak var universityListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition  = segue.identifier
        if(transition == "universityInfoSegue"){
            var destination = segue.destination as! UniversityInfoViewController
            destination.UniversityInfo = universityListArray![(universityListTableView.indexPathForSelectedRow?.row)!]
            destination.title = universityListArray![(universityListTableView.indexPathForSelectedRow?.row)!].collegeName
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
