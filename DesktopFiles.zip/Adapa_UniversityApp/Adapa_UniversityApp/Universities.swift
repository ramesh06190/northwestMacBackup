//
//  Universities.swift
//  Adapa_UniversityApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/20/23.
//

import Foundation
import UIKit


struct Universities {
    var domain: String
    var list_Array: [UniversityList]
}

struct UniversityList {
    var collegeName: String
    var collegeImage: UIImage
    var collegeInfo: String
}

let computerScienceDomain = Universities(domain: "Computer Science", list_Array: [
    UniversityList(collegeName: "Massachusetts Institute of Technology", collegeImage: UIImage(named: "mit")!, collegeInfo: "MIT is a private research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "Stanford University", collegeImage: UIImage(named: "stanford")!, collegeInfo: "Stanford is a private research university in Stanford, California."),
    UniversityList(collegeName: "Carnegie Mellon University", collegeImage: UIImage(named: "cmu")!, collegeInfo: "CMU is a private research university in Pittsburgh, Pennsylvania."),
    UniversityList(collegeName: "California Institute of Technology", collegeImage: UIImage(named: "caltech")!, collegeInfo: "Caltech is a private research university in Pasadena, California."),
    UniversityList(collegeName: "University of California, Berkeley", collegeImage: UIImage(named: "ucberkeley")!, collegeInfo: "UC Berkeley is a public research university in Berkeley, California.")
])

let dataScienceDomain = Universities(domain: "Data Science", list_Array: [
    UniversityList(collegeName: "New York University", collegeImage: UIImage(named: "nyu")!, collegeInfo: "NYU is a private research university in New York City."),
    UniversityList(collegeName: "Columbia University", collegeImage: UIImage(named: "columbia")!, collegeInfo: "Columbia is a private research university in New York City."),
    UniversityList(collegeName: "Johns Hopkins University", collegeImage: UIImage(named: "jhu")!, collegeInfo: "JHU is a private research university in Baltimore, Maryland."),
    UniversityList(collegeName: "University of Washington", collegeImage: UIImage(named: "uw")!, collegeInfo: "UW is a public research university in Seattle, Washington."),
    UniversityList(collegeName: "University of Michigan", collegeImage: UIImage(named: "umichigan")!, collegeInfo: "UMichigan is a public research university in Ann Arbor, Michigan.")
])

let itDomain = Universities(domain: "Information Technology", list_Array: [
    UniversityList(collegeName: "Harvard University", collegeImage: UIImage(named: "harvard")!, collegeInfo: "Harvard is a private research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "Princeton University", collegeImage: UIImage(named: "princeton")!, collegeInfo: "Princeton is a private research university in Princeton, New Jersey."),
    UniversityList(collegeName: "Yale University", collegeImage: UIImage(named: "yale")!, collegeInfo: "Yale is a private research university in New Haven, Connecticut."),
    UniversityList(collegeName: "University of Chicago", collegeImage: UIImage(named: "uchicago")!, collegeInfo: "UChicago is a private research university in Chicago, Illinois."),
    UniversityList(collegeName: "University of Pennsylvania", collegeImage: UIImage(named: "upenn")!, collegeInfo: "UPenn is a private research university in Philadelphia, Pennsylvania.")
])

let medicalDomain = Universities(domain: "Medical", list_Array: [
    UniversityList(collegeName: "Harvard University", collegeImage: UIImage(named: "harvard")!, collegeInfo: "Harvard is a private research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "Johns Hopkins University", collegeImage: UIImage(named: "jhu")!, collegeInfo: "JHU is a private research university in Baltimore, Maryland."),
    UniversityList(collegeName: "Stanford University", collegeImage: UIImage(named: "stanford")!, collegeInfo: "Stanford is a private research university in Stanford, California."),
    UniversityList(collegeName: "University of California, San Francisco", collegeImage: UIImage(named: "ucsf")!, collegeInfo: "UCSF is a public research university in San Francisco, California."),
    UniversityList(collegeName: "University of Michigan", collegeImage: UIImage(named: "umichigan")!, collegeInfo: "UMichigan is a public research university in Ann Arbor, Michigan.")
])

let businessDomain = Universities(domain: "Business", list_Array: [
    UniversityList(collegeName: "Harvard University", collegeImage: UIImage(named: "harvard")!, collegeInfo: "Harvard is a private research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "Stanford University", collegeImage: UIImage(named: "stanford")!, collegeInfo: "Stanford is a private research university in Stanford, California."),
    UniversityList(collegeName: "University of Pennsylvania", collegeImage: UIImage(named: "upenn")!, collegeInfo: "UPenn is a private research university in Philadelphia, Pennsylvania."),
    UniversityList(collegeName: "Massachusetts Institute of Technology", collegeImage: UIImage(named: "mit")!, collegeInfo: "MIT is a private research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "University of Chicago", collegeImage: UIImage(named: "uchicago")!, collegeInfo: "UChicago is a private research university in Chicago, Illinois.")
])

let domainsList = [computerScienceDomain, dataScienceDomain, itDomain, medicalDomain, businessDomain]
