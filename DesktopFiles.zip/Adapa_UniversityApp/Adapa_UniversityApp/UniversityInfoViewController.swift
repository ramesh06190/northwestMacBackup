//
//  UniversityInfoViewController.swift
//  Adapa_UniversityApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/20/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    var UniversityInfo : UniversityList?
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.text = UniversityInfo?.collegeInfo
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        universityImageViewOutlet.frame.origin.x = view.frame.width
        universityImageViewOutlet.image = UniversityInfo?.collegeImage
        UIView.animate(withDuration: 2, delay: 0.5, usingSpringWithDamping: 0.6, initialSpringVelocity: 0,animations: {
            self.universityImageViewOutlet.center.x = self.view.center.x
        })
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
