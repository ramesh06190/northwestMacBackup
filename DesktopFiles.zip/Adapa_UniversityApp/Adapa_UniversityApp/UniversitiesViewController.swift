//
//  ViewController.swift
//  Adapa_UniversityApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/19/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        domainsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = domainsList[indexPath.row].domain
        return cell
    }
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Domains"
        // Do any additional setup after loading the view.
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "listsSegue"){
            let destination = segue.destination as! UniversityListViewController
            destination.universityListArray = domainsList[(universitiesTableView.indexPathForSelectedRow?.row)!].list_Array
            destination.title = domainsList[(universitiesTableView.indexPathForSelectedRow?.row)!].domain
        }
    }

}

