//
//  MovieCollectionViewCell.swift
//  Adapa_Movies
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ImageOutlet: UIImageView!
    
    func assignMovie(with movie: Movie){
            ImageOutlet.image = movie.image
        }
}
