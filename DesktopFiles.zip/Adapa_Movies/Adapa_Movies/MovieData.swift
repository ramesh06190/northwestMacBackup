//
//  MovieData.swift
//  Adapa_Movies
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import Foundation
import UIKit
struct Movie {
    let title: String
    let image: UIImage
    let releasedYear: String
    let movieRating: String
    let boxOffice: String
    let moviePlot: String
    let cast: [String]
}

struct Genre {
    let category: String
    let movies: [Movie]
}

// Create movie data
let movieData: [Genre] = [
    Genre(category: "Drama", movies: [
        Movie(title: "Baahubali: The Beginning", image: UIImage(named: "baahubali")!, releasedYear: "2015", movieRating: "8.1", boxOffice: "₹1,800 crore", moviePlot: "In the kingdom of Mahishmati, a boy named Shivudu, raised by local villagers, learns about his true identity and begins his journey to avenge his father's death.", cast: ["Prabhas", "Rana Daggubati", "Anushka Shetty"]),
        Movie(title: "Arjun Reddy", image: UIImage(named: "arjun_reddy")!, releasedYear: "2017", movieRating: "8.2", boxOffice: "₹51 crore", moviePlot: "A brilliant medical student starts down a self-destructive path after his girlfriend is forced to marry another man.", cast: ["Vijay Deverakonda", "Shalini Pandey", "Rahul Ramakrishna"]),
        Movie(title: "Jersey", image: UIImage(named: "jersey")!, releasedYear: "2019", movieRating: "8.5", boxOffice: "₹51 crore", moviePlot: "A failed cricketer decides to revive his cricketing career to fulfill his son's wish.", cast: ["Nani", "Shraddha Srinath", "Sathyaraj"]),
        Movie(title: "Maharshi", image: UIImage(named: "maharshi")!, releasedYear: "2019", movieRating: "7.3", boxOffice: "₹175 crore", moviePlot: "Rishi, a successful entrepreneur, returns to his homeland and learns about the plight of farmers. He then decides to help them battle against the corporate system.", cast: ["Mahesh Babu", "Pooja Hegde", "Allari Naresh"]),
        Movie(title: "Ala Vaikunthapurramuloo", image: UIImage(named: "ala_vaikunthapurramuloo")!, releasedYear: "2020", movieRating: "7.9", boxOffice: "₹262 crore", moviePlot: "Bantu grows up being constantly subjected to his father's scorn. However, when he learns of his real parentage, he decides to carve a place for himself within the family he truly belongs to.", cast: ["Allu Arjun", "Pooja Hegde", "Tabu"])
    ]),
    Genre(category: "Comedy", movies: [
        Movie(title: "F2 - Fun and Frustration", image: UIImage(named: "f2")!, releasedYear: "2019", movieRating: "7.1", boxOffice: "₹150 crore", moviePlot: "Two men decide to take a holiday and end up in a Spanish village, where they encounter various problems due to their inability to speak Spanish.", cast: ["Venkatesh", "Varun Tej", "Tamannaah Bhatia"]),
        Movie(title: "Geetha Govindam", image: UIImage(named: "geetha_govindam")!, releasedYear: "2018", movieRating: "7.7", boxOffice: "₹130 crore", moviePlot: "Vijay meets Nithya in the strangest of circumstances and the two eventually fall in love. However, Vijay's job is at stake due to unexpected twists and turns in their relationship.", cast: ["Vijay Deverakonda", "Rashmika Mandanna", "Subbaraju"]),
        Movie(title: "Brochevarevarura", image: UIImage(named: "brochevarevarura")!, releasedYear: "2019", movieRating: "7.7", boxOffice: "₹20 crore", moviePlot: "Three youngsters meet accidentally in a drug deal plan to kidnap superstar Mahesh Babu to come out of their financial and personal crisis.", cast: ["Sree Vishnu", "Satya Dev", "Nivetha Thomas"]),
        Movie(title: "Bheeshma", image: UIImage(named: "bheeshma")!, releasedYear: "2020", movieRating: "6.6", boxOffice: "₹92 crore", moviePlot: "Bheeshma is a ruthless moneylender who will do anything for money. He falls for Chaitra and wants to impress her. But he gets embroiled in a fight with a powerful businessman, who has a dark secret.", cast: ["Nithiin", "Rashmika Mandanna", "Anant Nag"]),
        Movie(title: "Oh! Baby", image: UIImage(named: "oh_baby")!, releasedYear: "2019", movieRating: "7.5", boxOffice: "₹40 crore", moviePlot: "Savitri, a 70-year-old woman, gets a second chance to relive her youth when she mysteriously transforms into a young woman. She takes the opportunity to live the life she always wanted.", cast: ["Samantha Akkineni", "Lakshmi", "Rajendra Prasad"])
    ]),
 Genre(category: "Romance", movies: [
        Movie(title: "Arjun Reddy", image: UIImage(named: "arjun_reddy")!, releasedYear: "2017", movieRating: "8.2", boxOffice: "₹51 crore", moviePlot: "A brilliant medical student starts down a self-destructive path after his girlfriend is forced to marry another man.", cast: ["Vijay Deverakonda", "Shalini Pandey", "Rahul Ramakrishna"]),
        Movie(title: "Geetha Govindam", image: UIImage(named: "geetha_govindam")!, releasedYear: "2018", movieRating: "7.7", boxOffice: "₹130 crore", moviePlot: "Vijay meets Nithya in the strangest of circumstances and the two eventually fall in love. However, Vijay's job is at stake due to unexpected twists and turns in their relationship.", cast: ["Vijay Deverakonda", "Rashmika Mandanna", "Subbaraju"]),
        Movie(title: "Majili", image: UIImage(named: "majili")!, releasedYear: "2019", movieRating: "7.2", boxOffice: "₹75 crore", moviePlot: "Poorna, a young man, faces several challenges after his father's demise. He falls in love with Anshu, but she finds him irresponsible and immature. Will Poorna be able to win her over?", cast: ["Naga Chaitanya", "Samantha Akkineni", "Divyansha Kaushik"]),
        Movie(title: "Ninnu Kori", image: UIImage(named: "ninnu_kori")!, releasedYear: "2017", movieRating: "7.6", boxOffice: "₹60 crore", moviePlot: "Pallavi and Uma's marriage falls apart after an unforeseen tragedy. Years later, Pallavi is engaged to Arun, and Uma returns to her life, leading to a complex love triangle.", cast: ["Nani", "Nivetha Thomas", "Aadhi Pinisetty"]),
        Movie(title: "Oohalu Gusagusalade", image: UIImage(named: "oohalu_gusagusalade")!, releasedYear: "2014", movieRating: "7.8", boxOffice: "₹16 crore", moviePlot: "Venky and Praveen are bachelors who work for a software company. Venky's girlfriend dumps him, and he tries to commit suicide. Praveen convinces him to not do so, and the two end up falling in love with two women.", cast: ["Naga Shaurya", "Raashi Khanna", "Srinivas Avasarala"])
    ])
]
