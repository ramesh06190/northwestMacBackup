//
//  MoviesViewController.swift
//  Adapa_Movies
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    var moviesArray : [Movie]?  
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        moviesArray!.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: moviesArray![indexPath.row])
        return cell
    }
    
    
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           assignMovieDetails(index: indexPath)
       }
       
       func assignMovieDetails(index: IndexPath){
           movieNameLabel.text = "Movie Name: \(moviesArray![index.row].title)"
           movieRatingLabel.text = "Movie Rating: \(moviesArray![index.row].movieRating)"
           movieBoxOfficeLabel.text = "Box Office Collection: \(moviesArray![index.row].boxOffice)"
           moviePlotLabel.text = "Plot: \r\(moviesArray![index.row].moviePlot)"
           movieYearLabel.text = "Movie Released Year: \(moviesArray![index.row].releasedYear)"
           movieCastLabel.text = "Cast: \n\r\(moviesArray![index.row].cast.joined(separator: ", "))"
       }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieCollectionView.dataSource = self
        movieCollectionView.delegate = self
        
        movieNameLabel.text = "Movie Name: \(moviesArray![0].title)"
        movieRatingLabel.text = "Movie Rating: \(moviesArray![0].movieRating)"
        movieBoxOfficeLabel.text = "Box Office Collection: \(moviesArray![0].boxOffice)"
        moviePlotLabel.text = "Plot: \r\(moviesArray![0].moviePlot)"
        movieYearLabel.text = "Movie Released Year: \(moviesArray![0].releasedYear)"
        movieCastLabel.text = "Cast: \n\r\(moviesArray![0].cast.joined(separator: ", "))"


        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
