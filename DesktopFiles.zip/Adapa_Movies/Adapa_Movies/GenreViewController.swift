//
//  ViewController.swift
//  Adapa_Movies
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 4/27/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movieData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = movieData[indexPath.row].category
        return cell
    }
    

    @IBOutlet weak var genreTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        genreTableView.dataSource = self
        genreTableView.delegate = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trans = segue.identifier
        if(trans == "movieSegue"){
            var dest = segue.destination as! MoviesViewController
            dest.moviesArray = movieData[(genreTableView.indexPathForSelectedRow?.row)!].movies
        }
    }


}

